#!/usr/bin/python3
import yaml

ospf = True
configlet_directory = "./configlets/"

f = open("node1.yml", "r")
nodes = yaml.safe_load(f)
f.close()

def configlet_loopback(name, ip):
    print("interface %s" % (name))
    print("  ip address %s" % (ip))
    if ospf == True:
        print("ip area 0.0.0.0")

def write_configlet(configletname, configlet_contents):
   # filename = configlet_directory + configletname
    print(filename)
    #f = open(filname)


for switch in nodes:
    print('Switch: {}'.format(switch.get('name', '')))
    for interfaces in switch.get('interfaces', []):
        name = interfaces.get('name', '')
        ip = interfaces.get('ip', '')
        configlet = configlet_loopback(name, ip)
   # write_configlet(switch, "")




#print(nodes['dc1']['leaf1-dc1'])