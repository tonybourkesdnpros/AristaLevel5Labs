#!/usr/bin/python3
#The above is known as the "hashbang", which tells the shell where to find this scripts interpreter.

# Import two modules, requests and sys
import requests, sys

url = "https://192.168.0.21/command-api"


